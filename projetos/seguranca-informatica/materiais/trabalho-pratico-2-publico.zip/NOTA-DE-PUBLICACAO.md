# Trabalho Prático 2 — cópia pública revisada

Autoria: Alessandra Souza Garcia e Pedro Bampi Gollo.
Contexto: trabalho acadêmico de segurança informática, Universidade de Coimbra, 2026.

## Conteúdo preservado

O relatório mantém suas 23 páginas, títulos, estrutura, autoria e explicações técnicas. As configurações anexas conservam os bytes dos arquivos entregues; não foram corrigidas, modernizadas ou executadas nesta revisão. Os endereços e comandos de laboratório não devem ser usados como alvos ou configurações de produção.

## Alterações para publicação

- Ocultação de matrículas e de contatos pessoais identificados.
- Nos relatórios aplicáveis, remoção de capturas de autenticadores/códigos de recuperação e de trechos com tokens, valores de senhas ou dados de autenticação. Alguns blocos foram ocultados integralmente para não conservar fragmentos recuperáveis.
- As áreas ocultadas estão assinaladas em cinza no próprio PDF. Páginas com ocultações neste trabalho: 1, 5, 6, 13, 14, 16, 20.
- Inclusão de rodapé identificando a cópia pública revisada; limpeza de metadados, links/ações e anexos internos do PDF; recompressão de imagens sem reduzir suas dimensões em pixels.
- Exclusão de metadados auxiliares do macOS (`__MACOSX`).
- Quando presentes no pacote de origem, a assinatura PGP e a chave pública de verificação não foram incluídas: a assinatura original não autentica esta versão modificada. A chave pública não foi tratada como chave privada ou segredo.

## Limites e transparência

A redação técnica original foi mantida, inclusive conclusões e divergências apontadas na apresentação do portfólio. Esta revisão cuida da publicação; não representa repetição de testes, auditoria de segurança ou garantia de adequação das configurações.

Os originais não foram sobrescritos. A organização destes pacotes não reescreve o histórico do repositório nem invalida credenciais antigas. Os resultados pertencem exclusivamente aos cenários de laboratório descritos pela equipe.

## Integridade das configurações preservadas

Os valores abaixo são SHA-256 dos arquivos de configuração incluídos:

- `server.conf.txt`: `b4649b77b6bd2fbf8773f5c7482d14e6ae43a21774361180de461c7278797efa`
- `cliente.conf.txt`: `a1011a1354f203da1758717b84414cab8c704c03fda5066dda21a145a71b7ea3`
