# Trabalho Prático 3 — cópia pública revisada

Autoria: Alessandra Souza Garcia e Pedro Bampi Gollo.
Contexto: trabalho acadêmico de segurança informática, Universidade de Coimbra, 2026.

## Conteúdo preservado

O relatório mantém suas 114 páginas, títulos, estrutura, autoria e explicações técnicas. As configurações anexas conservam os bytes dos arquivos entregues; não foram corrigidas, modernizadas ou executadas nesta revisão. Os endereços e comandos de laboratório não devem ser usados como alvos ou configurações de produção.

## Alterações para publicação

- Ocultação de matrículas e de contatos pessoais identificados.
- Nos relatórios aplicáveis, remoção de capturas de autenticadores/códigos de recuperação e de trechos com tokens, valores de senhas ou dados de autenticação. Alguns blocos foram ocultados integralmente para não conservar fragmentos recuperáveis.
- As áreas ocultadas estão assinaladas em cinza no próprio PDF. Páginas com ocultações neste trabalho: 1, 22, 27, 30, 32, 35, 37, 39, 40, 43, 44, 45, 46, 47, 48, 49, 50, 52, 53, 66, 70, 99, 100, 103, 105.
- Inclusão de rodapé identificando a cópia pública revisada; limpeza de metadados, links/ações e anexos internos do PDF; recompressão de imagens sem reduzir suas dimensões em pixels.
- Exclusão de metadados auxiliares do macOS (`__MACOSX`).
- Quando presentes no pacote de origem, a assinatura PGP e a chave pública de verificação não foram incluídas: a assinatura original não autentica esta versão modificada. A chave pública não foi tratada como chave privada ou segredo.

## Limites e transparência

A redação técnica original foi mantida, inclusive conclusões e divergências apontadas na apresentação do portfólio. Esta revisão cuida da publicação; não representa repetição de testes, auditoria de segurança ou garantia de adequação das configurações.

Os originais não foram sobrescritos. A organização destes pacotes não reescreve o histórico do repositório nem invalida credenciais antigas. Os resultados pertencem exclusivamente aos cenários de laboratório descritos pela equipe.

## Integridade das configurações preservadas

Os valores abaixo são SHA-256 dos arquivos de configuração incluídos:

- `juiceshop.conf.txt`: `153efde87df53ea5bfdd0813ba3e1de63cef69dd6b2138874c80cfa9116b899f`
- `mod_security.conf.txt`: `754042722ff8c854aa1ea53bb671c2d7ce2b6254c79e48d521f2cbb87612088d`
